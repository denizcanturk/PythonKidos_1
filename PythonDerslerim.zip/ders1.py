print("Merhaba Deniz nasılsın?")
print("Bu benim ilk programım!...")

yas = 13

print(yas*2)

a = 5
b = 7

print(a+b, "Python")
 
yas = 45
ad = "Deniz"
print(ad,yas,"yasinda")

ad = input("Adinizi Giriniz :")
